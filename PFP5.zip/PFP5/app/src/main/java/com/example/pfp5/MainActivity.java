package com.example.pfp5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText email;
    private EditText contrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = (EditText) findViewById(R.id.txtEmail);
        SharedPreferences preferences = getSharedPreferences("datos", Context.MODE_PRIVATE);
        email.setText(preferences.getString("mail",""));
        contrasena = (EditText) findViewById(R.id.txtPassword);
        Button btnAcceder = (Button) findViewById(R.id.btnAcceder);
        Button btnRegistrarse = (Button) findViewById(R.id.btnRegistrarse);

        btnAcceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //SharedPreferences permite guardar el correo que se ingresa al inicio
                SharedPreferences preferences1 = getSharedPreferences("datos", Context.MODE_PRIVATE);
                SharedPreferences.Editor objEditor = preferences1.edit();
                objEditor.putString("mail", email.getText().toString());
                objEditor.commit();
                String Email_String = email.getText().toString();
                String Contrasena_String = contrasena.getText().toString();

                if(Email_String.isEmpty())
                {
                    //Toast.makeText(this, "Debe indicar un correo electrónico", Toast.LENGTH_SHORT).show();
                }
                if(Contrasena_String.isEmpty())
                {
                   //Toast.makeText(this, "Debe indicar una contraseña", Toast.LENGTH_SHORT).show();
                }

                Intent miActivity = new Intent(MainActivity.this, MainMenuActivity.class);
                        startActivity(miActivity);
            }
        });

        btnRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent miActivity = new Intent(MainActivity.this, Registrar.class);
                startActivity(miActivity);
            }
        });



    }
}