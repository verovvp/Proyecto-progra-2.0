package com.example.pfp5;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registrar extends AppCompatActivity {

    private EditText nombre;
    private EditText cedula;
    private EditText telefono;
    private EditText email;
    private EditText direccion;
    private EditText contrasena;
    private EditText repcontrasena;
    private Button btnRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        nombre = (EditText) findViewById(R.id.txtNombre);
        cedula = (EditText) findViewById(R.id.txtCedula);
        telefono = (EditText) findViewById(R.id.txtTelefono);
        email = (EditText) findViewById(R.id.txtEmail);
        direccion = (EditText) findViewById(R.id.txtDireccion);
        contrasena = (EditText) findViewById(R.id.txtPass);
        repcontrasena = (EditText) findViewById(R.id.txtRepetirPass);
    }

    public void registrar (View view)
    {
        String Nombre_String = nombre.getText().toString();
        String Cedula_String = cedula.getText().toString();
        String Telefono_String = telefono.getText().toString();
        String Email_String = email.getText().toString();
        String Direccion_String = direccion.getText().toString();
        String Contrasena_String = contrasena.getText().toString();
        String Repcontrasena_String = repcontrasena.getText().toString();

        if(Nombre_String.isEmpty())
        {
            Toast.makeText(this, "Debe incluir el nombre", Toast.LENGTH_SHORT).show();
        }
        if(Cedula_String.isEmpty())
        {
            Toast.makeText(this, "Debe incluir el número de identificación", Toast.LENGTH_SHORT).show();
        }
        if(Telefono_String.isEmpty())
        {
            Toast.makeText(this, "Debe incluir un número de contacto", Toast.LENGTH_SHORT).show();
        }
        if(Email_String.isEmpty())
        {
            Toast.makeText(this, "Debe incluir un correo electrónico", Toast.LENGTH_SHORT).show();
        }
        if(Direccion_String.isEmpty())
        {
            Toast.makeText(this, "Debe incluir la dirección exacta", Toast.LENGTH_SHORT).show();
        }
        if(Contrasena_String.isEmpty())
        {
            Toast.makeText(this, "Debe indicar una contraseña", Toast.LENGTH_SHORT).show();
        }
        if(Repcontrasena_String != Contrasena_String)
        {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
        }
        else if(btnRegistrar.isClickable())
        {
            Toast.makeText(this, "Usuario registrado con éxito", Toast.LENGTH_LONG).show();
        }
    }
}